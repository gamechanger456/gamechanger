import React, { useState, useEffect } from 'react';
import { Play, Info, Star, Calendar, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AnimeAPI } from '../services/api';

const HeroSection: React.FC = () => {
  const [featuredAnime, setFeaturedAnime] = useState<any>(null);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [slides, setSlides] = useState<any[]>([]);

  useEffect(() => {
    const fetchFeaturedAnime = async () => {
      try {
        const trending = await AnimeAPI.getTrendingAnime();
        const popular = await AnimeAPI.getPopularAnime();
        
        const combinedAnime = [...(trending.results || []), ...(popular.results || [])];
        const uniqueAnime = combinedAnime.filter((anime, index, self) => 
          index === self.findIndex((a) => a.id === anime.id)
        );
        
        const heroSlides = uniqueAnime.slice(0, 5);
        setSlides(heroSlides);
        setFeaturedAnime(heroSlides[0]);
      } catch (error) {
        console.error('Error fetching featured anime:', error);
      }
    };

    fetchFeaturedAnime();
  }, []);

  useEffect(() => {
    if (slides.length > 0) {
      const timer = setInterval(() => {
        setCurrentSlide((prev) => (prev + 1) % slides.length);
      }, 5000);

      return () => clearInterval(timer);
    }
  }, [slides.length]);

  useEffect(() => {
    if (slides.length > 0) {
      setFeaturedAnime(slides[currentSlide]);
    }
  }, [currentSlide, slides]);

  if (!featuredAnime) {
    return (
      <div className="relative h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-gray-900 flex items-center justify-center">
        <div className="animate-pulse text-white text-xl">Loading featured anime...</div>
      </div>
    );
  }

  return (
    <div className="relative h-screen overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={featuredAnime.image || '/placeholder-hero.jpg'}
          alt={featuredAnime.title}
          className="w-full h-full object-cover"
          onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = '/placeholder-hero.jpg';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-black/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl">
            {/* Title */}
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 leading-tight">
              {featuredAnime.title}
            </h1>

            {/* Metadata */}
            <div className="flex items-center space-x-4 mb-6 text-gray-300">
              {featuredAnime.releaseDate && (
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>{featuredAnime.releaseDate}</span>
                </div>
              )}
              {featuredAnime.totalEpisodes && (
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>{featuredAnime.totalEpisodes} Episodes</span>
                </div>
              )}
              {featuredAnime.status && (
                <div className="bg-green-500 text-white px-3 py-1 rounded-full text-sm">
                  {featuredAnime.status}
                </div>
              )}
            </div>

            {/* Genres */}
            {featuredAnime.genres && featuredAnime.genres.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-6">
                {featuredAnime.genres.slice(0, 4).map((genre: string, index: number) => (
                  <span
                    key={index}
                    className="bg-purple-600/80 text-white px-3 py-1 rounded-full text-sm"
                  >
                    {genre}
                  </span>
                ))}
              </div>
            )}

            {/* Description */}
            {featuredAnime.description && (
              <p className="text-gray-300 text-lg mb-8 line-clamp-3">
                {featuredAnime.description.replace(/<[^>]*>/g, '')}
              </p>
            )}

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <Link
                to={`/anime/${featuredAnime.id}`}
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center space-x-2 group"
              >
                <Play className="h-5 w-5 group-hover:scale-110 transition-transform" />
                <span>Watch Now</span>
              </Link>
              <Link
                to={`/anime/${featuredAnime.id}`}
                className="bg-gray-700/80 hover:bg-gray-600 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 flex items-center space-x-2 group"
              >
                <Info className="h-5 w-5 group-hover:scale-110 transition-transform" />
                <span>More Info</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? 'bg-purple-500' : 'bg-gray-500'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroSection;