import React from 'react';
import { Link } from 'react-router-dom';
import { Play, Star, Calendar, Clock, Heart, Plus, Check } from 'lucide-react';
import { useUser } from '../contexts/UserContext';

interface AnimeCardProps {
  anime: {
    id: string;
    title: string;
    image: string;
    releaseDate?: string;
    status?: string;
    totalEpisodes?: number;
    rating?: number;
    genres?: string[];
  };
  variant?: 'default' | 'large' | 'compact';
}

const AnimeCard: React.FC<AnimeCardProps> = ({ anime, variant = 'default' }) => {
  const { isLoggedIn, addToWatchlist, removeFromWatchlist, isInWatchlist } = useUser();
  const inWatchlist = isInWatchlist(anime.id);

  const cardSizeClasses = {
    default: 'aspect-[3/4] min-h-[300px]',
    large: 'aspect-[3/4] min-h-[400px]',
    compact: 'aspect-[3/4] min-h-[250px]'
  };

  const handleWatchlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isLoggedIn) return;
    
    if (inWatchlist) {
      removeFromWatchlist(anime.id);
    } else {
      addToWatchlist(anime);
    }
  };

  return (
    <Link to={`/anime/${anime.id}`}>
      <div className="group relative overflow-hidden rounded-lg bg-gray-800 hover:bg-gray-700 transition-all duration-300 hover:scale-105 hover:shadow-2xl">
        {/* Image Container */}
        <div className={`relative ${cardSizeClasses[variant]} overflow-hidden`}>
          <img
            src={anime.image || '/placeholder-anime.jpg'}
            alt={anime.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = '/placeholder-anime.jpg';
            }}
          />
          
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Play Button */}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="bg-purple-600 hover:bg-purple-700 rounded-full p-3 transform scale-90 group-hover:scale-100 transition-transform duration-300">
              <Play className="h-6 w-6 text-white fill-white" />
            </div>
          </div>

          {/* Watchlist Button */}
          {isLoggedIn && (
            <button
              onClick={handleWatchlistToggle}
              className={`absolute top-2 right-2 p-2 rounded-full transition-all duration-300 opacity-0 group-hover:opacity-100 ${
                inWatchlist 
                  ? 'bg-green-600 hover:bg-green-700 text-white' 
                  : 'bg-gray-800/80 hover:bg-gray-700 text-white backdrop-blur-sm'
              }`}
              title={inWatchlist ? 'Remove from watchlist' : 'Add to watchlist'}
            >
              {inWatchlist ? (
                <Check className="h-4 w-4" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
            </button>
          )}

          {/* Status Badge */}
          {anime.status && (
            <div className="absolute top-2 left-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
              {anime.status}
            </div>
          )}

          {/* Rating */}
          {anime.rating && (
            <div className="absolute bottom-2 left-2 bg-yellow-500 text-black text-xs px-2 py-1 rounded-full flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <Star className="h-3 w-3 fill-current" />
              <span>{anime.rating}</span>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="text-white font-semibold text-sm mb-2 line-clamp-2 group-hover:text-purple-400 transition-colors">
            {anime.title}
          </h3>
          
          {/* Metadata */}
          <div className="flex items-center justify-between text-gray-400 text-xs">
            <div className="flex items-center space-x-3">
              {anime.releaseDate && (
                <div className="flex items-center space-x-1">
                  <Calendar className="h-3 w-3" />
                  <span>{anime.releaseDate}</span>
                </div>
              )}
              {anime.totalEpisodes && (
                <div className="flex items-center space-x-1">
                  <Clock className="h-3 w-3" />
                  <span>{anime.totalEpisodes} eps</span>
                </div>
              )}
            </div>
          </div>

          {/* Genres */}
          {anime.genres && anime.genres.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {anime.genres.slice(0, 2).map((genre, index) => (
                <span
                  key={index}
                  className="bg-gray-700 text-gray-300 text-xs px-2 py-1 rounded"
                >
                  {genre}
                </span>
              ))}
              {anime.genres.length > 2 && (
                <span className="text-gray-500 text-xs px-2 py-1">
                  +{anime.genres.length - 2}
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </Link>
  );
};

export default AnimeCard;