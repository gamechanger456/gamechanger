import React, { useState } from 'react';
import { X, User, Settings, Heart, Clock, Star, TrendingUp, Edit2, Save, Camera } from 'lucide-react';
import { useUser } from '../contexts/UserContext';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose }) => {
  const { user, updatePreferences, updateFavoriteGenres, rateAnime, updateWatchStatus } = useUser();
  const [activeTab, setActiveTab] = useState<'profile' | 'watchlist' | 'preferences' | 'stats'>('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [editedGenres, setEditedGenres] = useState<string[]>(user?.favoriteGenres || []);

  if (!isOpen || !user) return null;

  const availableGenres = [
    'Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Horror', 'Mystery', 
    'Romance', 'Sci-Fi', 'Slice of Life', 'Sports', 'Supernatural', 'Thriller',
    'Mecha', 'Historical', 'Music', 'Psychological', 'School', 'Military'
  ];

  const handleGenreToggle = (genre: string) => {
    setEditedGenres(prev => 
      prev.includes(genre) 
        ? prev.filter(g => g !== genre)
        : [...prev, genre]
    );
  };

  const saveGenres = () => {
    updateFavoriteGenres(editedGenres);
    setIsEditing(false);
  };

  const getWatchlistStats = () => {
    const watching = user.watchlist.filter(item => item.watchStatus === 'watching').length;
    const completed = user.watchlist.filter(item => item.watchStatus === 'completed').length;
    const planToWatch = user.watchlist.filter(item => item.watchStatus === 'plan-to-watch').length;
    const dropped = user.watchlist.filter(item => item.watchStatus === 'dropped').length;
    const onHold = user.watchlist.filter(item => item.watchStatus === 'on-hold').length;

    return { watching, completed, planToWatch, dropped, onHold };
  };

  const stats = getWatchlistStats();

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <h2 className="text-2xl font-bold text-white">Profile</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          {[
            { id: 'profile', label: 'Profile', icon: User },
            { id: 'watchlist', label: 'Watchlist', icon: Heart },
            { id: 'preferences', label: 'Preferences', icon: Settings },
            { id: 'stats', label: 'Stats', icon: TrendingUp }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-6 py-4 transition-colors ${
                activeTab === tab.id
                  ? 'text-purple-400 border-b-2 border-purple-400'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <tab.icon className="h-5 w-5" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-6 max-h-96 overflow-y-auto">
          {/* Profile Tab */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              {/* User Info */}
              <div className="flex items-center space-x-6">
                <div className="relative">
                  <img
                    src={user.avatar}
                    alt={user.username}
                    className="w-24 h-24 rounded-full bg-gray-700"
                  />
                  <button className="absolute bottom-0 right-0 bg-purple-600 hover:bg-purple-700 p-2 rounded-full transition-colors">
                    <Camera className="h-4 w-4 text-white" />
                  </button>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white">{user.username}</h3>
                  <p className="text-gray-400">{user.email}</p>
                  <p className="text-sm text-gray-500 mt-1">
                    Member since {new Date(parseInt(user.id)).toLocaleDateString()}
                  </p>
                </div>
              </div>

              {/* Favorite Genres */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-white">Favorite Genres</h4>
                  <button
                    onClick={() => {
                      if (isEditing) {
                        saveGenres();
                      } else {
                        setIsEditing(true);
                      }
                    }}
                    className="flex items-center space-x-2 bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg transition-colors"
                  >
                    {isEditing ? <Save className="h-4 w-4" /> : <Edit2 className="h-4 w-4" />}
                    <span>{isEditing ? 'Save' : 'Edit'}</span>
                  </button>
                </div>

                {isEditing ? (
                  <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                    {availableGenres.map(genre => (
                      <button
                        key={genre}
                        onClick={() => handleGenreToggle(genre)}
                        className={`p-2 rounded-lg text-sm transition-colors ${
                          editedGenres.includes(genre)
                            ? 'bg-purple-600 text-white'
                            : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                        }`}
                      >
                        {genre}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {user.favoriteGenres.length > 0 ? (
                      user.favoriteGenres.map(genre => (
                        <span
                          key={genre}
                          className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm"
                        >
                          {genre}
                        </span>
                      ))
                    ) : (
                      <p className="text-gray-400">No favorite genres selected</p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Watchlist Tab */}
          {activeTab === 'watchlist' && (
            <div className="space-y-6">
              {/* Watchlist Stats */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-blue-400">{stats.watching}</div>
                  <div className="text-sm text-gray-400">Watching</div>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-green-400">{stats.completed}</div>
                  <div className="text-sm text-gray-400">Completed</div>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-yellow-400">{stats.planToWatch}</div>
                  <div className="text-sm text-gray-400">Plan to Watch</div>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-red-400">{stats.dropped}</div>
                  <div className="text-sm text-gray-400">Dropped</div>
                </div>
                <div className="bg-gray-700 p-4 rounded-lg text-center">
                  <div className="text-2xl font-bold text-orange-400">{stats.onHold}</div>
                  <div className="text-sm text-gray-400">On Hold</div>
                </div>
              </div>

              {/* Watchlist Items */}
              <div className="space-y-4">
                {user.watchlist.length > 0 ? (
                  user.watchlist.slice(0, 10).map(anime => (
                    <div key={anime.id} className="flex items-center space-x-4 bg-gray-700 p-4 rounded-lg">
                      <img
                        src={anime.image}
                        alt={anime.title}
                        className="w-16 h-20 object-cover rounded"
                      />
                      <div className="flex-1">
                        <h5 className="text-white font-medium">{anime.title}</h5>
                        <p className="text-gray-400 text-sm">
                          {anime.watchedEpisodes || 0} / {anime.totalEpisodes || '?'} episodes
                        </p>
                        <div className="flex items-center space-x-2 mt-2">
                          <select
                            value={anime.watchStatus}
                            onChange={(e) => updateWatchStatus(anime.id, e.target.value as any)}
                            className="bg-gray-600 text-white text-xs px-2 py-1 rounded"
                          >
                            <option value="watching">Watching</option>
                            <option value="completed">Completed</option>
                            <option value="plan-to-watch">Plan to Watch</option>
                            <option value="on-hold">On Hold</option>
                            <option value="dropped">Dropped</option>
                          </select>
                          <div className="flex items-center space-x-1">
                            {[1, 2, 3, 4, 5].map(star => (
                              <button
                                key={star}
                                onClick={() => rateAnime(anime.id, star)}
                                className={`text-sm ${
                                  (anime.userRating || 0) >= star ? 'text-yellow-400' : 'text-gray-500'
                                }`}
                              >
                                <Star className="h-4 w-4 fill-current" />
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-400 text-center py-8">Your watchlist is empty</p>
                )}
              </div>
            </div>
          )}

          {/* Preferences Tab */}
          {activeTab === 'preferences' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-white text-sm font-medium mb-2">
                    Preferred Language
                  </label>
                  <select
                    value={user.preferences.preferredLanguage}
                    onChange={(e) => updatePreferences({ preferredLanguage: e.target.value as 'sub' | 'dub' })}
                    className="w-full bg-gray-700 text-white rounded-lg py-2 px-3"
                  >
                    <option value="sub">Subtitled (Sub)</option>
                    <option value="dub">Dubbed (Dub)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white text-sm font-medium mb-2">
                    Default Quality
                  </label>
                  <select
                    value={user.preferences.quality}
                    onChange={(e) => updatePreferences({ quality: e.target.value })}
                    className="w-full bg-gray-700 text-white rounded-lg py-2 px-3"
                  >
                    <option value="Auto">Auto</option>
                    <option value="1080p">1080p</option>
                    <option value="720p">720p</option>
                    <option value="480p">480p</option>
                  </select>
                </div>

                <div>
                  <label className="block text-white text-sm font-medium mb-2">
                    Theme
                  </label>
                  <select
                    value={user.preferences.theme}
                    onChange={(e) => updatePreferences({ theme: e.target.value as 'dark' | 'light' })}
                    className="w-full bg-gray-700 text-white rounded-lg py-2 px-3"
                  >
                    <option value="dark">Dark</option>
                    <option value="light">Light</option>
                  </select>
                </div>

                <div className="flex items-center justify-between">
                  <label className="text-white text-sm font-medium">
                    Auto-play Next Episode
                  </label>
                  <button
                    onClick={() => updatePreferences({ autoplay: !user.preferences.autoplay })}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      user.preferences.autoplay ? 'bg-purple-600' : 'bg-gray-600'
                    }`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        user.preferences.autoplay ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Stats Tab */}
          {activeTab === 'stats' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-white">{user.watchlist.length}</div>
                  <div className="text-purple-100">Total Anime</div>
                </div>
                <div className="bg-gradient-to-r from-green-600 to-teal-600 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-white">{stats.completed}</div>
                  <div className="text-green-100">Completed</div>
                </div>
                <div className="bg-gradient-to-r from-yellow-600 to-orange-600 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-white">
                    {user.watchlist.reduce((total, anime) => total + (anime.watchedEpisodes || 0), 0)}
                  </div>
                  <div className="text-yellow-100">Episodes Watched</div>
                </div>
                <div className="bg-gradient-to-r from-red-600 to-pink-600 p-6 rounded-lg text-center">
                  <div className="text-3xl font-bold text-white">
                    {Math.round(user.watchlist.reduce((total, anime) => total + (anime.watchedEpisodes || 0), 0) * 24 / 60)}
                  </div>
                  <div className="text-red-100">Hours Watched</div>
                </div>
              </div>

              {/* Genre Distribution */}
              <div className="bg-gray-700 p-6 rounded-lg">
                <h4 className="text-lg font-semibold text-white mb-4">Genre Distribution</h4>
                <div className="space-y-2">
                  {user.favoriteGenres.slice(0, 5).map((genre, index) => (
                    <div key={genre} className="flex items-center justify-between">
                      <span className="text-gray-300">{genre}</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-32 bg-gray-600 rounded-full h-2">
                          <div
                            className="bg-purple-500 h-2 rounded-full"
                            style={{ width: `${Math.max(20, 100 - index * 15)}%` }}
                          />
                        </div>
                        <span className="text-gray-400 text-sm">{Math.max(20, 100 - index * 15)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;