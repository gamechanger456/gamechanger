import React, { useState } from 'react';
import { Search, Menu, X, Star, Sword, User, LogOut } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import ProfileModal from './ProfileModal';
import LoginModal from './LoginModal';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const navigate = useNavigate();
  const { user, isLoggedIn, logout } = useUser();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const handleProfileClick = () => {
    if (isLoggedIn) {
      setShowProfileModal(true);
    } else {
      setShowLoginModal(true);
    }
  };

  const handleLogout = () => {
    logout();
    setIsMenuOpen(false);
  };

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 bg-gray-900/95 backdrop-blur-sm border-b border-gray-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-3 group">
              <div className="relative">
                <div className="absolute -inset-2 bg-gradient-to-r from-purple-600 to-red-600 rounded-full blur-sm opacity-75 group-hover:opacity-100 transition-opacity"></div>
                <div className="relative bg-gradient-to-r from-purple-600 to-red-600 p-2 rounded-full">
                  <Sword className="h-6 w-6 text-white transform rotate-45" />
                </div>
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-red-400 bg-clip-text text-transparent group-hover:from-purple-300 group-hover:to-red-300 transition-all">
                  KatanaFlix
                </span>
                <span className="text-xs text-gray-400 -mt-1">Slice through entertainment</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <Link
                to="/"
                className="text-gray-300 hover:text-white transition-colors font-medium relative group"
              >
                Home
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-red-500 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                to="/trending"
                className="text-gray-300 hover:text-white transition-colors font-medium relative group"
              >
                Trending
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-red-500 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                to="/popular"
                className="text-gray-300 hover:text-white transition-colors font-medium relative group"
              >
                Popular
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-red-500 group-hover:w-full transition-all duration-300"></span>
              </Link>
              <Link
                to="/top-rated"
                className="text-gray-300 hover:text-white transition-colors font-medium flex items-center space-x-1 relative group"
              >
                <Star className="h-4 w-4" />
                <span>Top Rated</span>
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-purple-500 to-red-500 group-hover:w-full transition-all duration-300"></span>
              </Link>
            </nav>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="hidden md:block">
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search anime..."
                  className="w-64 bg-gray-800/80 text-white placeholder-gray-400 rounded-full py-2 px-4 pr-10 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:bg-gray-700/80 transition-all backdrop-blur-sm border border-gray-700/50"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                >
                  <Search className="h-5 w-5" />
                </button>
              </div>
            </form>

            {/* User Profile / Login */}
            <div className="hidden md:flex items-center space-x-4">
              {isLoggedIn ? (
                <div className="flex items-center space-x-3">
                  <button
                    onClick={handleProfileClick}
                    className="flex items-center space-x-2 bg-gray-800/80 hover:bg-gray-700 text-white px-4 py-2 rounded-full transition-all backdrop-blur-sm border border-gray-700/50"
                  >
                    <img
                      src={user?.avatar}
                      alt={user?.username}
                      className="w-6 h-6 rounded-full"
                    />
                    <span className="text-sm">{user?.username}</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="text-gray-400 hover:text-white transition-colors p-2"
                    title="Logout"
                  >
                    <LogOut className="h-5 w-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleProfileClick}
                  className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-red-600 hover:from-purple-700 hover:to-red-700 text-white px-4 py-2 rounded-full transition-all"
                >
                  <User className="h-5 w-5" />
                  <span>Sign In</span>
                </button>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-white hover:text-purple-400 transition-colors"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t border-gray-800">
              <form onSubmit={handleSearch} className="mt-4 mb-4">
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search anime..."
                    className="w-full bg-gray-800/80 text-white placeholder-gray-400 rounded-full py-2 px-4 pr-10 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:bg-gray-700/80 transition-all backdrop-blur-sm border border-gray-700/50"
                  />
                  <button
                    type="submit"
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  >
                    <Search className="h-5 w-5" />
                  </button>
                </div>
              </form>

              {/* Mobile User Section */}
              <div className="mb-4 pb-4 border-b border-gray-700">
                {isLoggedIn ? (
                  <div className="flex items-center justify-between">
                    <button
                      onClick={handleProfileClick}
                      className="flex items-center space-x-3"
                    >
                      <img
                        src={user?.avatar}
                        alt={user?.username}
                        className="w-8 h-8 rounded-full"
                      />
                      <div className="text-left">
                        <div className="text-white font-medium">{user?.username}</div>
                        <div className="text-gray-400 text-sm">View Profile</div>
                      </div>
                    </button>
                    <button
                      onClick={handleLogout}
                      className="text-gray-400 hover:text-white transition-colors p-2"
                    >
                      <LogOut className="h-5 w-5" />
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleProfileClick}
                    className="w-full bg-gradient-to-r from-purple-600 to-red-600 hover:from-purple-700 hover:to-red-700 text-white px-4 py-3 rounded-lg transition-all flex items-center justify-center space-x-2"
                  >
                    <User className="h-5 w-5" />
                    <span>Sign In</span>
                  </button>
                )}
              </div>

              <nav className="space-y-2">
                <Link
                  to="/"
                  className="block text-gray-300 hover:text-white transition-colors font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
                <Link
                  to="/trending"
                  className="block text-gray-300 hover:text-white transition-colors font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Trending
                </Link>
                <Link
                  to="/popular"
                  className="block text-gray-300 hover:text-white transition-colors font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Popular
                </Link>
                <Link
                  to="/top-rated"
                  className="flex items-center space-x-2 text-gray-300 hover:text-white transition-colors font-medium py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Star className="h-4 w-4" />
                  <span>Top Rated</span>
                </Link>
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Modals */}
      <ProfileModal isOpen={showProfileModal} onClose={() => setShowProfileModal(false)} />
      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} />
    </>
  );
};

export default Header;