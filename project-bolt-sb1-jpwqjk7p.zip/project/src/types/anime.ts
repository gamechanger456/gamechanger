export interface Anime {
  id: string;
  title: {
    romaji: string;
    english: string;
    native: string;
  };
  description: string;
  image: string;
  cover: string;
  status: string;
  releaseDate: number;
  genres: string[];
  totalEpisodes: number;
  duration: number;
  rating: number;
  popularity: number;
  studios: string[];
  trailer?: {
    id: string;
    site: string;
    thumbnail: string;
  };
}

export interface Episode {
  id: string;
  title: string;
  description: string;
  number: number;
  image: string;
  airDate: string;
}

export interface StreamingData {
  headers: Record<string, string>;
  sources: {
    url: string;
    quality: string;
    isM3U8: boolean;
  }[];
  download: string;
}

export interface SearchResult {
  id: string;
  title: string;
  image: string;
  releaseDate: string;
  subOrDub: string;
}