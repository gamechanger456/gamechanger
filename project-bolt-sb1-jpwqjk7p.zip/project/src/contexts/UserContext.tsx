import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AnimeItem {
  id: string;
  title: string;
  image: string;
  status?: string;
  rating?: number;
  genres?: string[];
  totalEpisodes?: number;
  watchedEpisodes?: number;
  dateAdded?: string;
  userRating?: number;
  watchStatus?: 'watching' | 'completed' | 'plan-to-watch' | 'dropped' | 'on-hold';
}

interface UserProfile {
  id: string;
  username: string;
  email: string;
  avatar: string;
  favoriteGenres: string[];
  watchlist: AnimeItem[];
  watchHistory: AnimeItem[];
  preferences: {
    preferredLanguage: 'sub' | 'dub';
    autoplay: boolean;
    quality: string;
    theme: 'dark' | 'light';
  };
  stats: {
    totalWatched: number;
    totalEpisodes: number;
    totalHours: number;
    favoriteGenre: string;
  };
}

interface UserContextType {
  user: UserProfile | null;
  isLoggedIn: boolean;
  login: (username: string, email: string) => void;
  logout: () => void;
  addToWatchlist: (anime: AnimeItem) => void;
  removeFromWatchlist: (animeId: string) => void;
  updateWatchStatus: (animeId: string, status: AnimeItem['watchStatus']) => void;
  updateWatchProgress: (animeId: string, episodeNumber: number) => void;
  rateAnime: (animeId: string, rating: number) => void;
  updatePreferences: (preferences: Partial<UserProfile['preferences']>) => void;
  updateFavoriteGenres: (genres: string[]) => void;
  isInWatchlist: (animeId: string) => boolean;
  getWatchlistByStatus: (status: AnimeItem['watchStatus']) => AnimeItem[];
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};

interface UserProviderProps {
  children: ReactNode;
}

export const UserProvider: React.FC<UserProviderProps> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Load user data from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('katanaflix-user');
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      setUser(userData);
      setIsLoggedIn(true);
    }
  }, []);

  // Save user data to localStorage whenever user changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('katanaflix-user', JSON.stringify(user));
    }
  }, [user]);

  const login = (username: string, email: string) => {
    const newUser: UserProfile = {
      id: Date.now().toString(),
      username,
      email,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
      favoriteGenres: [],
      watchlist: [],
      watchHistory: [],
      preferences: {
        preferredLanguage: 'sub',
        autoplay: true,
        quality: 'Auto',
        theme: 'dark'
      },
      stats: {
        totalWatched: 0,
        totalEpisodes: 0,
        totalHours: 0,
        favoriteGenre: ''
      }
    };
    setUser(newUser);
    setIsLoggedIn(true);
  };

  const logout = () => {
    setUser(null);
    setIsLoggedIn(false);
    localStorage.removeItem('katanaflix-user');
  };

  const addToWatchlist = (anime: AnimeItem) => {
    if (!user) return;
    
    const animeWithDefaults: AnimeItem = {
      ...anime,
      dateAdded: new Date().toISOString(),
      watchStatus: 'plan-to-watch',
      watchedEpisodes: 0
    };

    setUser(prev => {
      if (!prev) return prev;
      const isAlreadyInList = prev.watchlist.some(item => item.id === anime.id);
      if (isAlreadyInList) return prev;

      return {
        ...prev,
        watchlist: [...prev.watchlist, animeWithDefaults]
      };
    });
  };

  const removeFromWatchlist = (animeId: string) => {
    if (!user) return;
    
    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        watchlist: prev.watchlist.filter(item => item.id !== animeId)
      };
    });
  };

  const updateWatchStatus = (animeId: string, status: AnimeItem['watchStatus']) => {
    if (!user) return;
    
    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        watchlist: prev.watchlist.map(item =>
          item.id === animeId ? { ...item, watchStatus: status } : item
        )
      };
    });
  };

  const updateWatchProgress = (animeId: string, episodeNumber: number) => {
    if (!user) return;
    
    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        watchlist: prev.watchlist.map(item =>
          item.id === animeId 
            ? { 
                ...item, 
                watchedEpisodes: Math.max(item.watchedEpisodes || 0, episodeNumber),
                watchStatus: episodeNumber >= (item.totalEpisodes || 0) ? 'completed' : 'watching'
              } 
            : item
        )
      };
    });
  };

  const rateAnime = (animeId: string, rating: number) => {
    if (!user) return;
    
    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        watchlist: prev.watchlist.map(item =>
          item.id === animeId ? { ...item, userRating: rating } : item
        )
      };
    });
  };

  const updatePreferences = (preferences: Partial<UserProfile['preferences']>) => {
    if (!user) return;
    
    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        preferences: { ...prev.preferences, ...preferences }
      };
    });
  };

  const updateFavoriteGenres = (genres: string[]) => {
    if (!user) return;
    
    setUser(prev => {
      if (!prev) return prev;
      return {
        ...prev,
        favoriteGenres: genres
      };
    });
  };

  const isInWatchlist = (animeId: string): boolean => {
    if (!user) return false;
    return user.watchlist.some(item => item.id === animeId);
  };

  const getWatchlistByStatus = (status: AnimeItem['watchStatus']): AnimeItem[] => {
    if (!user) return [];
    return user.watchlist.filter(item => item.watchStatus === status);
  };

  const value: UserContextType = {
    user,
    isLoggedIn,
    login,
    logout,
    addToWatchlist,
    removeFromWatchlist,
    updateWatchStatus,
    updateWatchProgress,
    rateAnime,
    updatePreferences,
    updateFavoriteGenres,
    isInWatchlist,
    getWatchlistByStatus
  };

  return (
    <UserContext.Provider value={value}>
      {children}
    </UserContext.Provider>
  );
};