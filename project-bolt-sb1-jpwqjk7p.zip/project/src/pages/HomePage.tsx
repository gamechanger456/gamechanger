import React, { useState, useEffect } from 'react';
import HeroSection from '../components/HeroSection';
import AnimeSection from '../components/AnimeSection';
import { AnimeAPI } from '../services/api';

const HomePage: React.FC = () => {
  const [trendingAnime, setTrendingAnime] = useState<any[]>([]);
  const [popularAnime, setPopularAnime] = useState<any[]>([]);
  const [recentAnime, setRecentAnime] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHomeData = async () => {
      try {
        setLoading(true);
        const [trending, popular] = await Promise.all([
          AnimeAPI.getTrendingAnime(),
          AnimeAPI.getPopularAnime()
        ]);

        setTrendingAnime(trending.results || []);
        setPopularAnime(popular.results || []);
        setRecentAnime((popular.results || []).slice(10, 20));
      } catch (error) {
        console.error('Error fetching home data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHomeData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      <HeroSection />
      
      <div className="container mx-auto px-4 py-12">
        <AnimeSection title="Trending Now" animeList={trendingAnime} variant="large" />
        <AnimeSection title="Popular This Season" animeList={popularAnime} />
        <AnimeSection title="Recently Updated" animeList={recentAnime} variant="compact" />
      </div>
    </div>
  );
};

export default HomePage;