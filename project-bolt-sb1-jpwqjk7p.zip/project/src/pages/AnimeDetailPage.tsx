import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Play, Star, Calendar, Clock, Users, Heart, Share2, Plus, Check } from 'lucide-react';
import { AnimeAPI } from '../services/api';
import { useUser } from '../contexts/UserContext';

const AnimeDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [anime, setAnime] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { isLoggedIn, addToWatchlist, removeFromWatchlist, isInWatchlist } = useUser();

  const inWatchlist = anime ? isInWatchlist(anime.id) : false;

  useEffect(() => {
    const fetchAnimeDetails = async () => {
      if (!id) return;

      try {
        setLoading(true);
        const animeData = await AnimeAPI.getAnimeInfo(id);
        setAnime(animeData);
      } catch (error) {
        console.error('Error fetching anime details:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAnimeDetails();
  }, [id]);

  const handleWatchlistToggle = () => {
    if (!isLoggedIn || !anime) return;
    
    if (inWatchlist) {
      removeFromWatchlist(anime.id);
    } else {
      addToWatchlist(anime);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 pt-20 flex items-center justify-center">
        <div className="text-white text-xl">Loading anime details...</div>
      </div>
    );
  }

  if (!anime) {
    return (
      <div className="min-h-screen bg-gray-900 pt-20 flex items-center justify-center">
        <div className="text-white text-xl">Anime not found</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 pt-20">
      {/* Hero Section */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={anime.image || '/placeholder-anime.jpg'}
          alt={anime.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 -mt-32 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Poster */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <img
                src={anime.image || '/placeholder-anime.jpg'}
                alt={anime.title}
                className="w-full rounded-lg shadow-2xl"
              />
              
              {/* Action Buttons */}
              <div className="mt-6 space-y-3">
                {anime.episodes && anime.episodes.length > 0 && (
                  <Link
                    to={`/watch/${anime.episodes[0].id}`}
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
                  >
                    <Play className="h-5 w-5" />
                    <span>Watch Now</span>
                  </Link>
                )}
                
                {isLoggedIn && (
                  <button
                    onClick={handleWatchlistToggle}
                    className={`w-full py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2 ${
                      inWatchlist
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : 'bg-gray-700 hover:bg-gray-600 text-white'
                    }`}
                  >
                    {inWatchlist ? (
                      <>
                        <Check className="h-5 w-5" />
                        <span>In Watchlist</span>
                      </>
                    ) : (
                      <>
                        <Plus className="h-5 w-5" />
                        <span>Add to Watchlist</span>
                      </>
                    )}
                  </button>
                )}
                
                <button className="w-full bg-gray-700 hover:bg-gray-600 text-white py-3 px-6 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2">
                  <Share2 className="h-5 w-5" />
                  <span>Share</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column - Details */}
          <div className="lg:col-span-2">
            <div className="bg-gray-800 rounded-lg p-6 mb-6">
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">
                {anime.title}
              </h1>

              {/* Metadata */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-400">{anime.totalEpisodes || 'N/A'}</div>
                  <div className="text-gray-400 text-sm">Episodes</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-yellow-400 flex items-center justify-center">
                    <Star className="h-5 w-5 mr-1" />
                    {anime.rating || 'N/A'}
                  </div>
                  <div className="text-gray-400 text-sm">Rating</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-400">{anime.status || 'N/A'}</div>
                  <div className="text-gray-400 text-sm">Status</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-400">{anime.releaseDate || 'N/A'}</div>
                  <div className="text-gray-400 text-sm">Release</div>
                </div>
              </div>

              {/* Genres */}
              {anime.genres && anime.genres.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-white text-lg font-semibold mb-3">Genres</h3>
                  <div className="flex flex-wrap gap-2">
                    {anime.genres.map((genre: string, index: number) => (
                      <span
                        key={index}
                        className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm"
                      >
                        {genre}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Description */}
              {anime.description && (
                <div className="mb-6">
                  <h3 className="text-white text-lg font-semibold mb-3">Synopsis</h3>
                  <p className="text-gray-300 leading-relaxed">
                    {anime.description.replace(/<[^>]*>/g, '')}
                  </p>
                </div>
              )}
            </div>

            {/* Episodes List */}
            {anime.episodes && anime.episodes.length > 0 && (
              <div className="bg-gray-800 rounded-lg p-6">
                <h3 className="text-white text-lg font-semibold mb-4">Episodes</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                  {anime.episodes.map((episode: any, index: number) => (
                    <Link
                      key={episode.id}
                      to={`/watch/${episode.id}`}
                      className="bg-gray-700 hover:bg-gray-600 p-4 rounded-lg transition-colors group"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          <div className="w-16 h-12 bg-purple-600 rounded flex items-center justify-center">
                            <Play className="h-4 w-4 text-white" />
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="text-white font-medium group-hover:text-purple-400 transition-colors">
                            Episode {episode.number}
                          </div>
                          <div className="text-gray-400 text-sm line-clamp-2">
                            {episode.title || `Episode ${episode.number}`}
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnimeDetailPage;