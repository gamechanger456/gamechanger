import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, SkipBack, SkipForward, List, Download, Share2, Heart } from 'lucide-react';
import VideoPlayer from '../components/VideoPlayer';
import { AnimeAPI } from '../services/api';
import { useUser } from '../contexts/UserContext';

const WatchPage: React.FC = () => {
  const { episodeId } = useParams<{ episodeId: string }>();
  const [streamingData, setStreamingData] = useState<any>(null);
  const [animeInfo, setAnimeInfo] = useState<any>(null);
  const [currentEpisode, setCurrentEpisode] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showEpisodeList, setShowEpisodeList] = useState(false);
  const { updateWatchProgress } = useUser();

  // Sample subtitle and audio tracks for demonstration
  const sampleSubtitles = [
    { language: 'en', label: 'English', src: '/subtitles/en.vtt', default: true },
    { language: 'es', label: 'Español', src: '/subtitles/es.vtt' },
    { language: 'fr', label: 'Français', src: '/subtitles/fr.vtt' },
    { language: 'de', label: 'Deutsch', src: '/subtitles/de.vtt' },
    { language: 'pt', label: 'Português', src: '/subtitles/pt.vtt' },
    { language: 'it', label: 'Italiano', src: '/subtitles/it.vtt' },
    { language: 'ru', label: 'Русский', src: '/subtitles/ru.vtt' },
    { language: 'ar', label: 'العربية', src: '/subtitles/ar.vtt' },
    { language: 'zh', label: '中文', src: '/subtitles/zh.vtt' },
    { language: 'ja', label: '日本語', src: '/subtitles/ja.vtt' }
  ];

  const sampleAudioTracks = [
    { language: 'ja', label: 'Japanese (Original)', src: '/audio/ja.mp3', default: true },
    { language: 'en', label: 'English Dub', src: '/audio/en.mp3' },
    { language: 'es', label: 'Spanish Dub', src: '/audio/es.mp3' },
    { language: 'fr', label: 'French Dub', src: '/audio/fr.mp3' },
    { language: 'de', label: 'German Dub', src: '/audio/de.mp3' }
  ];

  useEffect(() => {
    const fetchStreamingData = async () => {
      if (!episodeId) return;

      try {
        setLoading(true);
        const streaming = await AnimeAPI.getEpisodeStreaming(episodeId);
        setStreamingData(streaming);

        // Extract anime ID from episode ID to get anime info
        const [animeId] = episodeId.split('-');
        const anime = await AnimeAPI.getAnimeInfo(animeId);
        setAnimeInfo(anime);

        // Find current episode
        const episodeNumber = parseInt(episodeId.split('-')[2]) || 1;
        const episode = anime?.episodes?.find((ep: any) => ep.number === episodeNumber);
        setCurrentEpisode(episode || { number: episodeNumber, title: `Episode ${episodeNumber}` });
      } catch (error) {
        console.error('Error fetching streaming data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStreamingData();
  }, [episodeId]);

  const handleTimeUpdate = (currentTime: number) => {
    // Save watch progress to localStorage
    if (episodeId) {
      localStorage.setItem(`watch-progress-${episodeId}`, currentTime.toString());
      
      // Update user watch progress if logged in
      if (animeInfo && currentEpisode) {
        updateWatchProgress(animeInfo.id, currentEpisode.number);
      }
    }
  };

  const handleEpisodeEnd = () => {
    // Auto-play next episode logic could go here
    console.log('Episode ended');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 pt-20 flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500"></div>
          <div className="text-white text-xl">Loading video...</div>
        </div>
      </div>
    );
  }

  if (!streamingData || !streamingData.sources || streamingData.sources.length === 0) {
    return (
      <div className="min-h-screen bg-gray-900 pt-20 flex items-center justify-center">
        <div className="text-center">
          <div className="text-white text-xl mb-4">Unable to load video</div>
          <p className="text-gray-400 mb-6">The video source is currently unavailable. Please try again later.</p>
          <Link
            to="/"
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition-colors"
          >
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  const videoSource = streamingData.sources.find((source: any) => source.quality === '720p') || streamingData.sources[0];

  return (
    <div className="min-h-screen bg-gray-900 pt-20">
      <div className="container mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <Link
              to={animeInfo ? `/anime/${animeInfo.id}` : "/"}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="h-6 w-6" />
            </Link>
            <div>
              <h1 className="text-white text-xl font-semibold">
                {animeInfo?.title || 'Unknown Anime'}
              </h1>
              <p className="text-gray-400 text-sm">
                {currentEpisode?.title || `Episode ${currentEpisode?.number || 1}`}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-lg transition-colors">
              <Heart className="h-5 w-5" />
            </button>
            <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-lg transition-colors">
              <Share2 className="h-5 w-5" />
            </button>
            <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-lg transition-colors">
              <Download className="h-5 w-5" />
            </button>
            <button
              onClick={() => setShowEpisodeList(!showEpisodeList)}
              className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-lg transition-colors flex items-center space-x-2"
            >
              <List className="h-5 w-5" />
              <span>Episodes</span>
            </button>
          </div>
        </div>

        {/* Video Player */}
        <div className="mb-8 aspect-video">
          <VideoPlayer
            src={videoSource.url}
            title={`${animeInfo?.title || 'Anime'} - ${currentEpisode?.title || `Episode ${currentEpisode?.number || 1}`}`}
            subtitles={sampleSubtitles}
            audioTracks={sampleAudioTracks}
            onTimeUpdate={handleTimeUpdate}
            onEnded={handleEpisodeEnd}
          />
        </div>

        {/* Episode Navigation */}
        <div className="flex items-center justify-between mb-8 bg-gray-800 rounded-lg p-6">
          <button className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed">
            <SkipBack className="h-5 w-5" />
            <span>Previous Episode</span>
          </button>
          
          <div className="text-center">
            <div className="text-white text-lg font-semibold">
              {currentEpisode?.title || `Episode ${currentEpisode?.number || 1}`}
            </div>
            <div className="text-gray-400">
              Episode {currentEpisode?.number || 1} of {animeInfo?.totalEpisodes || '?'}
            </div>
          </div>
          
          <button className="bg-gray-700 hover:bg-gray-600 text-white px-6 py-3 rounded-lg transition-colors flex items-center space-x-2">
            <span>Next Episode</span>
            <SkipForward className="h-5 w-5" />
          </button>
        </div>

        {/* Episode List Modal */}
        {showEpisodeList && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-gray-800 rounded-lg p-6 max-w-4xl w-full max-h-96 overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-white text-lg font-semibold">Episodes</h3>
                <button
                  onClick={() => setShowEpisodeList(false)}
                  className="text-gray-400 hover:text-white transition-colors text-2xl"
                >
                  ×
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {animeInfo?.episodes?.map((ep: any) => (
                  <Link
                    key={ep.id}
                    to={`/watch/${ep.id}`}
                    className={`bg-gray-700 hover:bg-gray-600 p-4 rounded-lg transition-colors ${
                      ep.number === currentEpisode?.number ? 'ring-2 ring-purple-500' : ''
                    }`}
                    onClick={() => setShowEpisodeList(false)}
                  >
                    <div className="text-white font-medium">Episode {ep.number}</div>
                    <div className="text-gray-400 text-sm line-clamp-2">
                      {ep.title || `Episode ${ep.number}`}
                    </div>
                  </Link>
                )) || Array.from({ length: animeInfo?.totalEpisodes || 12 }, (_, i) => (
                  <button
                    key={i + 1}
                    className={`bg-gray-700 hover:bg-gray-600 p-4 rounded-lg transition-colors text-left ${
                      (i + 1) === currentEpisode?.number ? 'ring-2 ring-purple-500' : ''
                    }`}
                  >
                    <div className="text-white font-medium">Episode {i + 1}</div>
                    <div className="text-gray-400 text-sm">Episode {i + 1}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Video Quality & Platform Selection */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Video Quality */}
          <div className="bg-gray-800 rounded-lg p-6">
            <h3 className="text-white text-lg font-semibold mb-4">Video Quality</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {streamingData.sources.map((source: any, index: number) => (
                <button
                  key={index}
                  className={`p-3 rounded-lg transition-colors text-center ${
                    source.url === videoSource.url
                      ? 'bg-purple-600 text-white'
                      : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                  }`}
                >
                  <div className="font-medium">{source.quality}</div>
                  <div className="text-xs opacity-75">{source.platform}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Streaming Platforms */}
          <div className="bg-gray-800 rounded-lg p-6">
            <h3 className="text-white text-lg font-semibold mb-4">Available Platforms</h3>
            <div className="space-y-2">
              {streamingData.platforms?.map((platform: any, index: number) => (
                <a
                  key={index}
                  href={platform.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block bg-gray-700 hover:bg-gray-600 p-3 rounded-lg transition-colors"
                >
                  <div className="text-white font-medium">{platform.name}</div>
                  <div className="text-gray-400 text-sm">Free streaming platform</div>
                </a>
              )) || (
                <div className="text-gray-400 text-center py-4">
                  No additional platforms available
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WatchPage;