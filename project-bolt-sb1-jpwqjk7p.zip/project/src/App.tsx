import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { UserProvider } from './contexts/UserContext';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import AnimeDetailPage from './pages/AnimeDetailPage';
import WatchPage from './pages/WatchPage';
import SearchPage from './pages/SearchPage';

function App() {
  return (
    <UserProvider>
      <Router>
        <div className="min-h-screen bg-gray-900">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/anime/:id" element={<AnimeDetailPage />} />
              <Route path="/watch/:episodeId" element={<WatchPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/trending" element={<SearchPage />} />
              <Route path="/popular" element={<SearchPage />} />
              <Route path="/top-rated" element={<SearchPage />} />
            </Routes>
          </main>
        </div>
      </Router>
    </UserProvider>
  );
}

export default App;