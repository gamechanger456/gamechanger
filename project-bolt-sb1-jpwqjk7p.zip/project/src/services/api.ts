const MAL_BASE_URL = 'https://api.jikan.moe/v4';

// Simple in-memory cache
const cache = new Map<string, { data: any; timestamp: number }>();
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Rate limiting - increased from 1000ms to 2000ms to avoid 429 errors
let lastRequestTime = 0;
const MIN_REQUEST_INTERVAL = 2000; // 2 seconds between requests

// Free streaming platforms configuration
const STREAMING_PLATFORMS = {
  ANIME_PLANET: {
    name: 'Anime-Planet',
    baseUrl: 'https://www.anime-planet.com',
    searchUrl: 'https://www.anime-planet.com/anime/all',
    watchUrl: 'https://www.anime-planet.com/anime'
  },
  TUBI: {
    name: 'Tubi TV',
    baseUrl: 'https://tubitv.com',
    searchUrl: 'https://tubitv.com/search',
    watchUrl: 'https://tubitv.com/movies'
  },
  RETROCRUSH: {
    name: 'RetroCrush',
    baseUrl: 'https://www.retrocrush.tv',
    searchUrl: 'https://www.retrocrush.tv/search',
    watchUrl: 'https://www.retrocrush.tv/series'
  },
  CRUNCHYROLL_FREE: {
    name: 'Crunchyroll (Free)',
    baseUrl: 'https://www.crunchyroll.com',
    searchUrl: 'https://www.crunchyroll.com/search',
    watchUrl: 'https://www.crunchyroll.com/series'
  },
  FUNIMATION_FREE: {
    name: 'Funimation (Free)',
    baseUrl: 'https://www.funimation.com',
    searchUrl: 'https://www.funimation.com/search',
    watchUrl: 'https://www.funimation.com/shows'
  }
};

export class AnimeAPI {
  // Helper method to add delay between requests
  private static async rateLimitedFetch(url: string): Promise<Response> {
    const now = Date.now();
    const timeSinceLastRequest = now - lastRequestTime;
    
    if (timeSinceLastRequest < MIN_REQUEST_INTERVAL) {
      const delay = MIN_REQUEST_INTERVAL - timeSinceLastRequest;
      await new Promise(resolve => setTimeout(resolve, delay));
    }
    
    lastRequestTime = Date.now();
    return fetch(url);
  }

  // Helper method to get cached data or fetch new data
  private static async getCachedOrFetch(cacheKey: string, fetchFn: () => Promise<any>): Promise<any> {
    const cached = cache.get(cacheKey);
    const now = Date.now();
    
    if (cached && (now - cached.timestamp) < CACHE_DURATION) {
      console.log(`Using cached data for ${cacheKey}`);
      return cached.data;
    }
    
    try {
      const data = await fetchFn();
      cache.set(cacheKey, { data, timestamp: now });
      return data;
    } catch (error) {
      // If we have expired cached data, use it as fallback
      if (cached) {
        console.log(`Using expired cached data for ${cacheKey} due to error:`, error);
        return cached.data;
      }
      throw error;
    }
  }

  // Helper method to remove duplicates based on anime ID
  private static removeDuplicates(animeList: any[]): any[] {
    const seen = new Set();
    return animeList.filter(anime => {
      if (seen.has(anime.id)) {
        return false;
      }
      seen.add(anime.id);
      return true;
    });
  }

  // Helper method to transform MAL anime data
  private static transformMALAnime(anime: any) {
    return {
      id: anime.mal_id.toString(),
      title: anime.title,
      image: anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url || anime.images?.webp?.large_image_url || anime.images?.webp?.image_url,
      releaseDate: anime.year?.toString() || 'N/A',
      status: anime.status,
      totalEpisodes: anime.episodes,
      rating: anime.score,
      genres: anime.genres?.map((g: any) => g.name) || [],
      description: anime.synopsis
    };
  }

  // Helper method to generate streaming links for free platforms
  private static generateStreamingLinks(animeTitle: string, animeId: string) {
    const normalizedTitle = animeTitle.toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '-');

    return {
      animePlanet: `${STREAMING_PLATFORMS.ANIME_PLANET.watchUrl}/${normalizedTitle}`,
      tubi: `${STREAMING_PLATFORMS.TUBI.watchUrl}/${animeId}`,
      retroCrush: `${STREAMING_PLATFORMS.RETROCRUSH.watchUrl}/${normalizedTitle}`,
      crunchyrollFree: `${STREAMING_PLATFORMS.CRUNCHYROLL_FREE.watchUrl}/${animeId}/${normalizedTitle}`,
      funimationFree: `${STREAMING_PLATFORMS.FUNIMATION_FREE.watchUrl}/${normalizedTitle}`
    };
  }

  // Helper method to create episode streaming data with free platform links
  private static createEpisodeStreamingData(animeTitle: string, episodeNumber: number, animeId: string) {
    const streamingLinks = this.generateStreamingLinks(animeTitle, animeId);
    
    return {
      sources: [
        {
          url: `${streamingLinks.animePlanet}/episodes/${episodeNumber}`,
          quality: '1080p',
          isM3U8: false,
          platform: 'Anime-Planet',
          free: true
        },
        {
          url: `${streamingLinks.tubi}/episode-${episodeNumber}`,
          quality: '720p',
          isM3U8: false,
          platform: 'Tubi TV',
          free: true
        },
        {
          url: `${streamingLinks.retroCrush}/episode-${episodeNumber}`,
          quality: '720p',
          isM3U8: false,
          platform: 'RetroCrush',
          free: true
        },
        {
          url: `${streamingLinks.crunchyrollFree}/episode-${episodeNumber}`,
          quality: '1080p',
          isM3U8: true,
          platform: 'Crunchyroll (Free)',
          free: true
        },
        {
          url: `${streamingLinks.funimationFree}/episode-${episodeNumber}`,
          quality: '1080p',
          isM3U8: false,
          platform: 'Funimation (Free)',
          free: true
        }
      ],
      platforms: Object.values(STREAMING_PLATFORMS).map(platform => ({
        name: platform.name,
        url: platform.baseUrl,
        searchUrl: platform.searchUrl
      }))
    };
  }

  // MyAnimeList API methods for anime data
  static async getTrendingAnime() {
    return this.getCachedOrFetch('trending', async () => {
      try {
        const response = await this.rateLimitedFetch(`${MAL_BASE_URL}/top/anime?filter=airing&limit=20`);
        if (!response.ok) {
          console.error(`MAL API request failed with status: ${response.status}`);
          if (response.status === 429) {
            console.log('Rate limited by MAL API, using fallback data');
          }
          return this.getFallbackTrendingData();
        }
        const data = await response.json();
        const animeList = data.data?.map(this.transformMALAnime) || [];
        return {
          results: this.removeDuplicates(animeList)
        };
      } catch (error) {
        console.error('Error fetching trending anime from MAL:', error);
        return this.getFallbackTrendingData();
      }
    });
  }

  static async getPopularAnime() {
    return this.getCachedOrFetch('popular', async () => {
      try {
        const response = await this.rateLimitedFetch(`${MAL_BASE_URL}/top/anime?filter=bypopularity&limit=20`);
        if (!response.ok) {
          console.error(`MAL API request failed with status: ${response.status}`);
          if (response.status === 429) {
            console.log('Rate limited by MAL API, using fallback data');
          }
          return this.getFallbackPopularData();
        }
        const data = await response.json();
        const animeList = data.data?.map(this.transformMALAnime) || [];
        return {
          results: this.removeDuplicates(animeList)
        };
      } catch (error) {
        console.error('Error fetching popular anime from MAL:', error);
        return this.getFallbackPopularData();
      }
    });
  }

  static async searchAnime(query: string) {
    const cacheKey = `search-${query}`;
    return this.getCachedOrFetch(cacheKey, async () => {
      try {
        const response = await this.rateLimitedFetch(
          `${MAL_BASE_URL}/anime?q=${encodeURIComponent(query)}&limit=20`
        );
        if (!response.ok) {
          console.error(`MAL search request failed with status: ${response.status}`);
          if (response.status === 429) {
            console.log('Rate limited by MAL API during search');
          }
          return { results: [] };
        }
        const data = await response.json();
        const animeList = data.data?.map(this.transformMALAnime) || [];
        return {
          results: this.removeDuplicates(animeList)
        };
      } catch (error) {
        console.error('Error searching anime on MAL:', error);
        return { results: [] };
      }
    });
  }

  static async getAnimeInfo(id: string) {
    const cacheKey = `anime-${id}`;
    return this.getCachedOrFetch(cacheKey, async () => {
      try {
        // First get anime details from MAL
        const animeResponse = await this.rateLimitedFetch(`${MAL_BASE_URL}/anime/${id}/full`);
        if (!animeResponse.ok) {
          console.error(`MAL anime info request failed with status: ${animeResponse.status}`);
          if (animeResponse.status === 429) {
            console.log('Rate limited by MAL API for anime info');
          }
          return this.getFallbackAnimeInfo(id);
        }
        const animeData = await animeResponse.json();
        const anime = animeData.data;

        // Try to get episodes from MAL with additional delay
        let episodes = [];
        try {
          await new Promise(resolve => setTimeout(resolve, 1500)); // Extra delay for episodes
          const episodesResponse = await this.rateLimitedFetch(`${MAL_BASE_URL}/anime/${id}/episodes`);
          if (episodesResponse.ok) {
            const episodesData = await episodesResponse.json();
            episodes = episodesData.data?.map((ep: any) => ({
              id: `${id}-episode-${ep.mal_id}`,
              number: ep.mal_id,
              title: ep.title || `Episode ${ep.mal_id}`,
              url: ep.url,
              streamingLinks: this.generateStreamingLinks(anime.title, id)
            })) || [];
          }
        } catch (episodeError) {
          console.error('Error fetching episodes:', episodeError);
        }

        // If no episodes from MAL, create placeholder episodes with streaming links
        if (episodes.length === 0 && anime.episodes) {
          episodes = Array.from({ length: Math.min(anime.episodes, 50) }, (_, i) => ({
            id: `${id}-episode-${i + 1}`,
            number: i + 1,
            title: `Episode ${i + 1}`,
            streamingLinks: this.generateStreamingLinks(anime.title, id)
          }));
        }

        return {
          id: anime.mal_id.toString(),
          title: anime.title,
          description: anime.synopsis,
          image: anime.images?.jpg?.large_image_url || anime.images?.jpg?.image_url || anime.images?.webp?.large_image_url || anime.images?.webp?.image_url,
          releaseDate: anime.year?.toString() || 'N/A',
          status: anime.status,
          genres: anime.genres?.map((g: any) => g.name) || [],
          totalEpisodes: anime.episodes,
          rating: anime.score,
          duration: anime.duration,
          studios: anime.studios?.map((s: any) => s.name) || [],
          episodes: episodes,
          streamingPlatforms: Object.values(STREAMING_PLATFORMS).map(platform => ({
            name: platform.name,
            url: platform.baseUrl,
            searchUrl: `${platform.searchUrl}?q=${encodeURIComponent(anime.title)}`
          }))
        };
      } catch (error) {
        console.error('Error fetching anime info from MAL:', error);
        return this.getFallbackAnimeInfo(id);
      }
    });
  }

  static async getTopRatedAnime() {
    return this.getCachedOrFetch('toprated', async () => {
      try {
        const response = await this.rateLimitedFetch(`${MAL_BASE_URL}/top/anime?filter=favorite&limit=20`);
        if (!response.ok) {
          console.error(`MAL top rated request failed with status: ${response.status}`);
          if (response.status === 429) {
            console.log('Rate limited by MAL API for top rated');
          }
          return [];
        }
        const data = await response.json();
        const animeList = data.data?.map(this.transformMALAnime) || [];
        return this.removeDuplicates(animeList);
      } catch (error) {
        console.error('Error fetching top rated anime from MAL:', error);
        return [];
      }
    });
  }

  static async getSeasonalAnime(year?: number, season?: string) {
    const cacheKey = `seasonal-${year || 'current'}-${season || 'current'}`;
    return this.getCachedOrFetch(cacheKey, async () => {
      try {
        const currentYear = year || new Date().getFullYear();
        const currentSeason = season || this.getCurrentSeason();
        const response = await this.rateLimitedFetch(`${MAL_BASE_URL}/seasons/${currentYear}/${currentSeason}`);
        if (!response.ok) {
          console.error(`MAL seasonal request failed with status: ${response.status}`);
          if (response.status === 429) {
            console.log('Rate limited by MAL API for seasonal anime');
          }
          return [];
        }
        const data = await response.json();
        const animeList = data.data?.map(this.transformMALAnime) || [];
        return this.removeDuplicates(animeList);
      } catch (error) {
        console.error('Error fetching seasonal anime from MAL:', error);
        return [];
      }
    });
  }

  // Enhanced episode streaming with free platform integration
  static async getEpisodeStreaming(episodeId: string) {
    const cacheKey = `streaming-${episodeId}`;
    return this.getCachedOrFetch(cacheKey, async () => {
      try {
        // Extract anime ID and episode number from episodeId
        const [animeId, , episodeNumber] = episodeId.split('-');
        
        // Get anime info to get the title for streaming links
        const animeInfo = await this.getAnimeInfo(animeId);
        const animeTitle = animeInfo?.title || 'Unknown Anime';
        const epNumber = parseInt(episodeNumber) || 1;

        // Create streaming data with free platform links
        const streamingData = this.createEpisodeStreamingData(animeTitle, epNumber, animeId);
        
        return {
          ...streamingData,
          animeTitle,
          episodeNumber: epNumber,
          episodeTitle: `Episode ${epNumber}`,
          description: `Watch ${animeTitle} Episode ${epNumber} for free on multiple platforms.`
        };
      } catch (error) {
        console.error('Error creating episode streaming data:', error);
        return this.getFallbackStreamingData();
      }
    });
  }

  // Get available streaming platforms for an anime
  static async getStreamingPlatforms(animeTitle: string, animeId: string) {
    const streamingLinks = this.generateStreamingLinks(animeTitle, animeId);
    
    return {
      platforms: [
        {
          name: 'Anime-Planet',
          url: streamingLinks.animePlanet,
          description: 'Free anime streaming with ads',
          features: ['HD Quality', 'Large Library', 'Community Reviews'],
          free: true
        },
        {
          name: 'Tubi TV',
          url: streamingLinks.tubi,
          description: 'Free movies and TV shows',
          features: ['HD Quality', 'No Subscription Required', 'Mobile App'],
          free: true
        },
        {
          name: 'RetroCrush',
          url: streamingLinks.retroCrush,
          description: 'Classic anime streaming',
          features: ['Retro Anime', 'Free with Ads', 'Curated Collection'],
          free: true
        },
        {
          name: 'Crunchyroll (Free)',
          url: streamingLinks.crunchyrollFree,
          description: 'Free tier with ads',
          features: ['Latest Episodes', 'HD Quality', 'Simulcast'],
          free: true
        },
        {
          name: 'Funimation (Free)',
          url: streamingLinks.funimationFree,
          description: 'Free dubbed anime',
          features: ['English Dubs', 'Free Episodes', 'Mobile Friendly'],
          free: true
        }
      ]
    };
  }

  // Helper methods
  static getCurrentSeason() {
    const month = new Date().getMonth() + 1;
    if (month >= 1 && month <= 3) return 'winter';
    if (month >= 4 && month <= 6) return 'spring';
    if (month >= 7 && month <= 9) return 'summer';
    return 'fall';
  }

  // Fallback data methods
  static getFallbackTrendingData() {
    return {
      results: [
        {
          id: '16498',
          title: 'Attack on Titan',
          image: 'https://cdn.myanimelist.net/images/anime/10/47347l.jpg',
          releaseDate: '2013',
          status: 'Finished Airing',
          totalEpisodes: 25,
          rating: 9.0,
          genres: ['Action', 'Drama', 'Fantasy'],
          description: 'Humanity fights for survival against giant humanoid Titans.'
        },
        {
          id: '44511',
          title: 'Chainsaw Man',
          image: 'https://cdn.myanimelist.net/images/anime/1806/126216l.jpg',
          releaseDate: '2022',
          status: 'Finished Airing',
          totalEpisodes: 12,
          rating: 8.7,
          genres: ['Action', 'Supernatural'],
          description: 'Denji becomes the Chainsaw Devil to pay off his debts.'
        },
        {
          id: '40748',
          title: 'Jujutsu Kaisen',
          image: 'https://cdn.myanimelist.net/images/anime/1171/109222l.jpg',
          releaseDate: '2020',
          status: 'Finished Airing',
          totalEpisodes: 24,
          rating: 8.5,
          genres: ['Action', 'School', 'Supernatural'],
          description: 'Students fight cursed spirits in modern Japan.'
        }
      ]
    };
  }

  static getFallbackPopularData() {
    return {
      results: [
        {
          id: '20',
          title: 'Naruto',
          image: 'https://cdn.myanimelist.net/images/anime/13/17405l.jpg',
          releaseDate: '2002',
          status: 'Finished Airing',
          totalEpisodes: 220,
          rating: 8.3,
          genres: ['Action', 'Martial Arts', 'Shounen'],
          description: 'A young ninja seeks recognition and dreams of becoming the Hokage.'
        },
        {
          id: '31964',
          title: 'My Hero Academia',
          image: 'https://cdn.myanimelist.net/images/anime/10/78745l.jpg',
          releaseDate: '2016',
          status: 'Finished Airing',
          totalEpisodes: 13,
          rating: 7.9,
          genres: ['Action', 'School', 'Shounen'],
          description: 'In a world of superheroes, a quirkless boy aims to become the greatest hero.'
        },
        {
          id: '813',
          title: 'Dragon Ball Z',
          image: 'https://cdn.myanimelist.net/images/anime/1277/142715l.jpg',
          releaseDate: '1989',
          status: 'Finished Airing',
          totalEpisodes: 291,
          rating: 8.7,
          genres: ['Action', 'Adventure', 'Martial Arts'],
          description: 'Goku and friends defend Earth from powerful enemies.'
        }
      ]
    };
  }

  static getFallbackAnimeInfo(id: string) {
    return {
      id,
      title: 'Sample Anime',
      description: 'This is a sample anime description for demonstration purposes. The anime follows the journey of a young protagonist who discovers their hidden powers and must save the world from an ancient evil.',
      image: 'https://cdn.myanimelist.net/images/anime/1806/126216l.jpg',
      releaseDate: '2023',
      status: 'Currently Airing',
      genres: ['Action', 'Adventure', 'Drama', 'Fantasy'],
      totalEpisodes: 24,
      rating: 8.5,
      duration: 24,
      studios: ['Studio Example'],
      episodes: Array.from({ length: 12 }, (_, i) => ({
        id: `${id}-episode-${i + 1}`,
        number: i + 1,
        title: `Episode ${i + 1}`,
        streamingLinks: this.generateStreamingLinks('Sample Anime', id)
      })),
      streamingPlatforms: Object.values(STREAMING_PLATFORMS).map(platform => ({
        name: platform.name,
        url: platform.baseUrl,
        searchUrl: `${platform.searchUrl}?q=sample+anime`
      }))
    };
  }

  static getFallbackStreamingData() {
    return {
      sources: [
        {
          url: 'https://www.anime-planet.com/anime/sample-anime/episodes/1',
          quality: '1080p',
          isM3U8: false,
          platform: 'Anime-Planet',
          free: true
        },
        {
          url: 'https://tubitv.com/movies/sample-anime-episode-1',
          quality: '720p',
          isM3U8: false,
          platform: 'Tubi TV',
          free: true
        },
        {
          url: 'https://www.retrocrush.tv/series/sample-anime/episode-1',
          quality: '720p',
          isM3U8: false,
          platform: 'RetroCrush',
          free: true
        }
      ],
      platforms: Object.values(STREAMING_PLATFORMS).map(platform => ({
        name: platform.name,
        url: platform.baseUrl,
        searchUrl: platform.searchUrl
      })),
      animeTitle: 'Sample Anime',
      episodeNumber: 1,
      episodeTitle: 'Episode 1',
      description: 'Watch Sample Anime Episode 1 for free on multiple platforms.'
    };
  }
}